package com.example.leeyu.touch_interface;

import android.annotation.SuppressLint;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Touch_Interface extends AppCompatActivity {
    public static boolean touch_flag;
    static String Result="";
    static String tempResult="";
    static long start_time, current_time;
    static boolean time_flag;

    @SuppressLint({"ClickableViewAccessibility", "WrongViewCast", "CutPasteId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView result = (TextView) findViewById(R.id.result);
        final EditText etPasswd = (EditText) findViewById(R.id.passwd);
        etPasswd.setInputType(0);
        final CheckBox cb = (CheckBox) findViewById(R.id.checkbox);
        final EditText PressView = (EditText) findViewById(R.id.PressView);
        final EditText TouchView = (EditText) findViewById(R.id.TouchView);
        final DBHelper dbHelper = new DBHelper(getApplicationContext(), "PasswdCheck.db", null, 1);
        final Button[] Buttons = new Button[12];
        final Integer[] Button = {R.id.button0, R.id.button1, R.id.button2, R.id.button3, R.id.button4, R.id.button5,
                R.id.button6, R.id.button7, R.id.button8, R.id.button9, R.id.button11}; //11(C) 12(OK)
//        Button button12 = (Button)findViewById(R.id.button12) ;

        start_time = 0;
        current_time = 0;
        touch_flag = time_flag = false;



        for (int i = 0; i < Button.length; i++)
            Buttons[i] = (Button) findViewById(Button[i]);

        for (int i = 0; i < Button.length; i++) {
            final int index;
            index = i;

            //12개의 버튼에 리스너 등록
            /*
             * 첫 번째 파라미터: 처음 터치한 후 반복이 실행되기 까지의 대기시간
             * 두 번째 파라미터: 반복속도
             */
            Buttons[index].setOnTouchListener(new RepeatListener(0, 50, Buttons[i], new View.OnTouchListener() {
                public boolean onTouch(View view, MotionEvent event) {
                    Float PressureThreshold = event.getPressure(); //압력값 PressureThreshold변수에 저장.

                    //시간값 체크
                    if(time_flag){
                        current_time = SystemClock.currentThreadTimeMillis();
                    }else{
                        current_time = start_time = SystemClock.currentThreadTimeMillis();
                        time_flag = true;
                    }

                    long real_time = current_time - start_time;

                    if ((event.getAction() == MotionEvent.ACTION_DOWN) || (event.getAction() == MotionEvent.AXIS_PRESSURE)) {
                        if (index == 10) { //취소(C)
                            String tempText = etPasswd.getText().toString();
                                if (tempText.length() > 0) {
                                    Result = "";
                                    tempResult = "";
                                    tempResult = tempText.substring(0, tempText.length() - 1);
                                    etPasswd.setText(tempResult);
                                }

                        } else if (index == 11) { // OK
                        } else { // 숫자버튼 입력

                            PressView.setText(PressureThreshold.toString()); //압력값 화면에 출력.
                            System.out.print("\n 압력 :" + PressureThreshold);//압력값 로그에 출력.
                            System.out.print("\n 시간 :" + real_time); //압력값 로그에 출력.

                            if (PressureThreshold < 0.2 && real_time < 100)  { // Tab
                                tempResult = "T" + index;
                                if(!touch_flag){
                                    etPasswd.append(String.valueOf(index));
//                                    Result += "T" + index;
                                    touch_flag=true;
                                }
                                TouchView.setText("TAB Touch");

                            }
                            else if (PressureThreshold >= 0.2 && PressureThreshold < 0.4 && real_time <100) { //3D(약한세기)
                                tempResult = "PS" + index;
//                                Result += "PS" + index;
                                if(!touch_flag){
                                    etPasswd.append(String.valueOf(index));
                                    touch_flag=true;
                                }
                                TouchView.setText("3D(Soft)");
                            }
                            else if (PressureThreshold >= 0.4 && PressureThreshold < 0.7 && real_time <100 ) { //3D(중간세기)
                                tempResult = "PM" + index;
//                                Result += "PM" + index;
                                if(!touch_flag){
                                    etPasswd.append(String.valueOf(index));
                                    touch_flag=true;
                                }
                                TouchView.setText("3D(Middle)");
                            }
                            else if (PressureThreshold >= 0.7 && real_time <100 ) { //3D(강한세기)
                                tempResult = "PH" + index;
//                                Result += "PH" + index;
                                if(!touch_flag){
                                    etPasswd.append(String.valueOf(index));
                                    touch_flag=true;
                                }
                                TouchView.setText("3D(Hard)");
                            }
                            else if (real_time >= 100) {
                                tempResult = "L" + index;
//                                Result += "L" + index;
                                if(!touch_flag){
                                    etPasswd.append(String.valueOf(index));
                                    touch_flag=true;
                                }
                                TouchView.setText("LONG Touch");
                            }
                        }
                    }
                    return false;
                }
            }));



            final Button insert = (Button) findViewById(R.id.insert);
            insert.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dbHelper.insert(Result); // 요기 가로 안에
                    // result.setText(dbHelper.getResult());
                }
            });
            Button delete = (Button) findViewById(R.id.delete);
            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dbHelper.delete(Result);
                    //  result.setText(dbHelper.getResult());
                }
            });

            Button select = (Button) findViewById(R.id.button12);
            select.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Boolean isPassword1 = true;
                    isPassword1 = dbHelper.check(Result);

                    if (isPassword1) {
                        Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_LONG).show();
                        result.setText("Password O");
                    } else if (isPassword1.equals("")) {
                        Toast.makeText(Touch_Interface.this, "Please Enter Your Password", Toast.LENGTH_LONG).show();
                        result.setText("Password X");
                    } else {
                        Toast.makeText(Touch_Interface.this, "Password Incorrect", Toast.LENGTH_LONG).show();
                        result.setText("Password X");
                    }
                }
            });
            Button allselect = (Button) findViewById(R.id.allselect);
            allselect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Button select = (Button) findViewById(R.id.button12);
                    result.setText(dbHelper.getResult());

                }
            });

//            if (!dbHelper.isPasswdExist()) {
//                Toast.makeText(getApplicationContext(), "비밀번호를 먼저 등록해주세요", Toast.LENGTH_LONG).show();
//            }

            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (!isChecked) {
                        etPasswd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    } else {
                        etPasswd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    }
                }
            });
        }
    }
}