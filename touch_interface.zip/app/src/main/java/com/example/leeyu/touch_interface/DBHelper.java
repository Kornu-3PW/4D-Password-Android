package com.example.leeyu.touch_interface;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE PASSWORDCHECK(_id INTEGER PRIMARY KEY AUTOINCREMENT, passwd TEXT);");
        Log.d("DBHelper", "onCreate method complete!");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insert(String passwd) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            String sql = "INSERT INTO PASSWORDCHECK VALUES(null,'" + passwd + "');";
            db.execSQL(sql);
            db.close();
            Log.d("DBHelper - insert", sql+" : complete!");
        }catch (Exception e){
            Log.e("DBHelper - insert",e.getMessage());
        }
    }
    public void update(String passwd){

    }

    public void delete(String passwd) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            String sql = "DELETE FROM PASSWORDCHECK WHERE passwd='" + passwd + "';";
            db.execSQL(sql);
            db.close();
            Log.d("DBHelper - delete", sql+" : complete!");
        } catch (Exception e){
            Log.e("DBHelper - delete",e.getMessage());
        }
    }

    public Boolean check(String passwd){
        try{
            SQLiteDatabase db = getReadableDatabase();
            String sql = "SELECT _id FROM PASSWORDCHECK WHERE passwd='" + passwd + "';";
            Cursor cursor = db.rawQuery(sql,null); // where
            Log.d("DBHelper - check(mid)",sql);

            if(cursor.getCount() == 0){
                Log.d("DBHelper - check(res)","false");
                return false;
            }else{
                Log.d("DBHelper - check(res)","true");
                return true;
            }
        }catch (Exception e){
            Log.e("DBHelper - check", e.getMessage());
            return false;
        }
    }

    public Boolean isPasswdExist(){
        try{
            SQLiteDatabase db = getReadableDatabase();
            String sql = "SELECT _id FROM PASSWORDCHECK";
            Cursor cursor = db.rawQuery(sql,null); // where
            Log.d("DBHelper-isPasswdExist",sql);

            if(cursor.getCount() == 0){
                Log.d("DBHelper-isPasswdExist","false");
                return false;
            }else{
                Log.d("DBHelper-isPasswdExist","true");
                return true;
            }
        }catch (Exception e){
            Log.e("DBHelper-isPasswdExist", e.getMessage());
            return false;
        }
    }

    public String getResult(){
        SQLiteDatabase db = getReadableDatabase();
        String result = "" ;

        Cursor cursor = db.rawQuery("SELECT * FROM PASSWORDCHECK",null);
        while(cursor.moveToNext()){
            result += cursor.getString(0)
                    + ":"
                    + cursor.getString(1)
                    + "\n" ;
        }
        return  result ;
    }

    public String allResult(){
        SQLiteDatabase db = getReadableDatabase();
        String result = "" ;

        Cursor cursor = db.rawQuery("SELECT * FROM PASSWORDCHECK",null);
        while(cursor.moveToNext()) {
            result += cursor.getString(0)
                    + ":"
                    + cursor.getString(1)
                    + "\n";
        }
        return result ;
    }
}