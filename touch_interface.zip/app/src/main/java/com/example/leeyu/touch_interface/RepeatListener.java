package com.example.leeyu.touch_interface;

import android.view.MotionEvent;
import android.os.Handler;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;

/**
 * A class, that can be used as a TouchListener on any view (e.g. a Button).
 * It cyclically runs a clickListener, emulating keyboard-like behaviour. First
 * click is fired immediately, next after initialInterval, and subsequent after
 * normalInterval.
 *
 * <p>Interval is scheduled after the onClick completes, so it has to run fast.
 * If it runs slow, it does not generate skipped onClicks.
 */

public class RepeatListener implements OnTouchListener {

    private Handler handler = new Handler();

    private int initialInterval;
    private final int normalInterval;
    private final OnTouchListener touchListener;

    private Runnable handlerRunnable = new Runnable() {
        @Override
        public void run() {
            handler.postDelayed(this, normalInterval);
            touchListener.onTouch(downView, event);
        }
    };

    private View downView;
    private MotionEvent event;
    private Button  Buttons;

    /**
     * @param initialInterval The interval after first click event
     * @param normalInterval The interval after second and subsequent click
     *       events
     * @param touchListener The OnTouchListener, that will be called
     */
    public RepeatListener(int initialInterval, int normalInterval, Button Buttons,
                          OnTouchListener touchListener) {

        if (touchListener == null)
            throw new IllegalArgumentException("null runnable");
        if (initialInterval < 0 || normalInterval < 0)
            throw new IllegalArgumentException("negative interval");
        this.initialInterval = initialInterval;
        this.normalInterval = normalInterval;
        this.touchListener = touchListener;
        this.Buttons = Buttons;
    }

    public boolean onTouch(View view, MotionEvent motion) {
        switch (motion.getAction()) {
            case MotionEvent.ACTION_DOWN:
                handler.removeCallbacks(handlerRunnable);
                handler.postDelayed(handlerRunnable, initialInterval);
                downView = view;
                event = motion;
                // touchListener.onTouch(downView, event);
                break;

            case MotionEvent.ACTION_UP:
                handler.removeCallbacks(handlerRunnable);
                downView = view;
                Touch_Interface.time_flag=false;
                Touch_Interface.current_time =0;
                Touch_Interface.start_time =0;
                Touch_Interface.touch_flag=false;
                Touch_Interface.Result += Touch_Interface.tempResult;
                return true;

            //동작 안함
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(handlerRunnable);
                downView = null;
                return true;

            //동작 안함
            case MotionEvent.ACTION_OUTSIDE:
                handler.removeCallbacks(handlerRunnable);
                downView = null;
                return true;
        }
        return false;
    }
}
